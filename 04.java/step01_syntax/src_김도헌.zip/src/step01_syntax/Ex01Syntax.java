package step01_syntax;

public class Ex01Syntax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello, Java");
		
	
	}

}
