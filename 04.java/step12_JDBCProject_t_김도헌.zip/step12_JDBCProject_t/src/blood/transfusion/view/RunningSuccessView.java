package blood.transfusion.view;

public class RunningSuccessView {
	
	public static void showSuccess(String message){
		System.out.println(message);		
	}
	
}
